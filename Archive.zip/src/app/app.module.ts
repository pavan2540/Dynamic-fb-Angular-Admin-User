import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

// Material Imports
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatNativeDateModule, MatOptionModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatToolbarModule } from '@angular/material/toolbar';
import { DragDropModule } from '@angular/cdk/drag-drop';

// NgRx
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { FormTemplateEffects } from './state/form-template.effects';
import { formTemplateReducer } from './state/form-template.reducer';

// Components
import { AppComponent } from './app.component';
import { LoginComponent } from './auth/login/login.component';
import { FormBuilderComponent } from './form-builder/form-builder.component';
import { FormListComponent } from './form-management/form-list/form-list.component';
import { FormEditComponent } from './form-management/form-edit/form-edit.component';
import { FormFillComponent } from './form-submission/form-fill/form-fill.component';
import { SubmittedFormsComponent } from './form-submission/submitted-forms/submitted-forms.component';
import { FieldConfigDialogComponent } from './field-config-dialog/field-config-dialog.component';
import { FormPreviewComponent } from './form-preview/form-preview.component';

// Services
import { FormTemplateService } from './services/form-template.service';
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    FormBuilderComponent,
    FormListComponent,
    FormEditComponent,
    FormPreviewComponent,
    FormFillComponent,
    SubmittedFormsComponent,
    FieldConfigDialogComponent
  ],
  imports: [
    // Angular Core
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AppRoutingModule,
    
    // Material Modules
    MatButtonModule,
    MatCardModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatDialogModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatNativeDateModule,
    MatOptionModule,
    MatRadioModule,
    MatSelectModule,
    MatSnackBarModule,
    MatToolbarModule,
    DragDropModule,
    
    // Store configuration
    StoreModule.forRoot({ formTemplates: formTemplateReducer }),
    EffectsModule.forRoot([FormTemplateEffects])
  ],
  providers: [FormTemplateService],
  bootstrap: [AppComponent]
})
export class AppModule { }