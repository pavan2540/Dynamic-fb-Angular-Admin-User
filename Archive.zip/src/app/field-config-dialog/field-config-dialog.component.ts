import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-field-config-dialog',
  templateUrl: './field-config-dialog.component.html'
})
export class FieldConfigDialogComponent {
  form: FormGroup;

  constructor(
    public dialogRef: MatDialogRef<FieldConfigDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder
  ) {
    this.form = this.fb.group({
      label: [data.label || ''],
      required: [data.required || false],
      helpText: [data.helpText || ''],
      minLength: [data.minLength || ''],
      maxLength: [data.maxLength || ''],
      pattern: [data.pattern || '']
    });
  }

  onSave(): void {
    this.dialogRef.close(this.form.value);
  }

  onCancel(): void {
    this.dialogRef.close();
  }
}
