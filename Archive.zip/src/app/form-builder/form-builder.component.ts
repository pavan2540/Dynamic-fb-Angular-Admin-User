import { Component } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { MatDialog } from '@angular/material/dialog';
import { FieldConfigDialogComponent } from '../field-config-dialog/field-config-dialog.component';

@Component({
  selector: 'app-form-builder',
  templateUrl: './form-builder.component.html',
  styleUrls: ['./form-builder.component.scss']
})
export class FormBuilderComponent {
  availableFields = [
    { type: 'text', label: 'Text Input' },
    { type: 'textarea', label: 'Multiline Text' },
    { type: 'select', label: 'Dropdown' },
    { type: 'checkbox', label: 'Checkbox Group' },
    { type: 'radio', label: 'Radio Group' },
    { type: 'date', label: 'Date Picker' }
  ];

  formFields: any[] = [];

  constructor(private dialog: MatDialog) {}

  drop(event: CdkDragDrop<any[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(this.formFields, event.previousIndex, event.currentIndex);
    } else {
      const field = { ...event.previousContainer.data[event.previousIndex], id: Date.now(), config: {} };
      this.formFields.splice(event.currentIndex, 0, field);
    }
  }

  editField(field: any) {
    const dialogRef = this.dialog.open(FieldConfigDialogComponent, {
      width: '400px',
      data: field.config || {}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        field.config = result;
      }
    });
  }

  saveForm() {
    console.log('Saved Form:', this.formFields);
    // Save form to API or state (to be implemented)
  }
}