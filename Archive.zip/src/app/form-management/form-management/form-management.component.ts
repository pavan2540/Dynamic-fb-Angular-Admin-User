import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-management',
  templateUrl: './form-management.component.html',
  styleUrls: ['./form-management.component.scss']
})
export class FormManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
