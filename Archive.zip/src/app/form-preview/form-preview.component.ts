import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FormTemplateService } from '../services/form-template.service';

@Component({
  selector: 'app-form-preview',
  templateUrl: './form-preview.component.html',
  styleUrls: ['./form-preview.component.scss']
})
export class FormPreviewComponent implements OnInit {
  form: FormGroup = this.fb.group({});
  formFields: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private formService: FormTemplateService,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.formService.getTemplateById(id).subscribe(template => {
        if (template) {
          this.formFields = template.fields || [];
          this.buildForm();
        }
      });
    }
  }

  buildForm(): void {
    for (let field of this.formFields) {
      this.form.addControl(field.key, this.fb.control(''));
    }
  }
}
