import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FormTemplate, FormTemplateService } from 'src/app/services/form-template.service';
import { MatSnackBar } from '@angular/material/snack-bar';

export interface FieldConfig {
  key: string;
  label: string;
  type: string;
  required?: boolean;
  options?: string[];
}

export const fieldsData: FieldConfig[] = [
  {
    key: 'name',
    label: 'Name',
    type: 'text',
    required: true
  },
  {
    key: 'description',
    label: 'Description',
    type: 'textarea',
    required: false
  },
  {
    key: 'gender',
    label: 'Gender',
    type: 'radio',
    options: ['Male', 'Female'],
    required: true
  },
  {
    key: 'hobbies',
    label: 'Hobbies',
    type: 'checkbox',
    options: ['Reading', 'Traveling', 'Sports']
  },
  {
    key: 'country',
    label: 'Country',
    type: 'select',
    options: ['USA', 'India', 'Canada']
  },
  {
    key: 'dob',
    label: 'Date of Birth',
    type: 'date'
  }
];

@Component({
  selector: 'app-form-fill',
  templateUrl: './form-fill.component.html'
})

export class FormFillComponent implements OnInit {
  formGroup!: FormGroup;
  fields: any[] = [];
  today = new Date();
  form: FormGroup<{ [key: string]: FormControl<any>; }> | undefined;

  constructor(private fb: FormBuilder,
    private formTemplateService: FormTemplateService,
    private router: Router,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    // Replace this with dynamic loading if needed
    this.fields = fieldsData;

    const group: any = {};

    this.fields.forEach(field => {
      if (field.type === 'checkbox') {
        const checkboxArray = field.options.map(() => false);
        group[field.key] = this.fb.array(checkboxArray);
      } else {
        group[field.key] = field.required
          ? [null, Validators.required]
          : [null];
      }
    });


    this.route.paramMap.subscribe(params => {
      const templateId = params.get('id');
      if (templateId) {
        this.loadTemplate(templateId);
      }
      if (templateId) {
        if (this.form) {
          Object.values(this.form.controls).forEach(control => {
            control.disable();
          });
        }
      }

      if (params.get('isPreview') === 'true' && this.form) {
        Object.values(this.form.controls).forEach(control => {
          control.disable();
        });
      }
    });
    // Initialize form group with dynamic fields
    this.formGroup = this.fb.group(group);
  }

  loadTemplate(id: string): void {
    this.formTemplateService.getTemplateById(id).subscribe(template => {
      if (template) {
        console.log('Loaded template:', template);
        this.formGroup.patchValue(template);
        this.formGroup.markAsPristine();
        this.formGroup.markAsUntouched();
        this.fields = template.fields || [];
        this.populateForm(template);
      }
    });
  }

  populateForm(template: FormTemplate): void {
  //  Assuming template.fields is an array of form controls
  //  Create a reactive form group from the template data
    const group: { [key: string]: FormControl } = {};
    template.fields.forEach(field => {
      group[field.name] = new FormControl(field.value);
    });
  
    this.form = new FormGroup(group);
  }


  onSubmit() {
    if (this.formGroup.valid) {
      this.formTemplateService.saveTemplate(this.formGroup.value);
      this.snackBar.open('Form submitted successfully!', 'Close', {
        duration: 3000,
        panelClass: ['success-snackbar']
      });
      console.log('Submitted form value:', this.formGroup.value);
    } else {
      this.formGroup.markAllAsTouched();
      this.snackBar.open('Please fill all required fields correctly!', 'Close', {
        duration: 3000,
        panelClass: ['error-snackbar']
      });
    }
  }

  getCheckboxOptions(key: string): any {
    return this.formGroup.get(key) as FormArray;
  }
}
