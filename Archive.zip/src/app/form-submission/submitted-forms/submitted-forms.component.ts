import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submitted-forms',
  templateUrl: './submitted-forms.component.html',
  styleUrls: ['./submitted-forms.component.scss']
})
export class SubmittedFormsComponent implements OnInit {
  submittedForms: any[] = [];

  constructor() { }

  ngOnInit(): void {
    this.submittedForms = JSON.parse(localStorage.getItem('submitted_forms') || '[]');
  }

}
